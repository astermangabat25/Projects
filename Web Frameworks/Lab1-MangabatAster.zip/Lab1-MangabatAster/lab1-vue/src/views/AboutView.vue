<template>
  <div class="flex items-center justify-center min-h-screen bg-gray-100">
    <h1 class="text-4xl font-bold text-blue-600 mb-4">
      Hello, Tailwind CSS!
    </h1>
  </div>
</template>