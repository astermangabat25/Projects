package app.components;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.entities.Sighting;
import app.repositories.SightingRepository;

@Component
public class SightingComponent {
	@Autowired
	private SightingRepository repo;
	
	public Sighting add(Long animalID, String location, Double latitude, Double longtitude, String comment) {
		Sighting sight = new Sighting();
		sight.setAnimalID(animalID);
		sight.setLocation(location);
		sight.setLatitude(latitude);
		sight.setLongtitude(longtitude);
		sight.setComment(comment);
		
		sight = repo.save(sight);
		
		return sight;
	}
}
