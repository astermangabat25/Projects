package app.entities;

import javax.persistence.*;
import javax.validation.constraints.*;

import org.hibernate.validator.constraints.Range;


@Entity
public class Sighting {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Long id;
	
	@Column
	@NotNull
	private Long animalID;
	
	@Column
	@NotNull
	private String location;
	
	@Column
	@Range(min=-90, max=90)
	private Double latitude;
	
	@Column
	@Range(min=-180, max=180)
	private Double longtitude;
	
	@Column
	private String comment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAnimalID() {
		return animalID;
	}

	public void setAnimalID(Long animalID) {
		this.animalID = animalID;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(Double longtitude) {
		this.longtitude = longtitude;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "Sighting [id=" + id + ", animalID=" + animalID + ", location=" + location + ", latitude=" + latitude
				+ ", longtitude=" + longtitude + ", comment=" + comment + "]";
	}

	
	
}
