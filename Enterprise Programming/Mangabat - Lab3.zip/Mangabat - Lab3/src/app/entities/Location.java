package app.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
public class Location {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Long id;
	
	@Column
	@NotNull
	private String locationName;
	
	@Column
	@Range(min=-90, max=90)
	private Double latitude;
	
	@Column
	@Range(min=-180, max=180)
	private Double longtitude;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(Double longtitude) {
		this.longtitude = longtitude;
	}

	@Override
	public String toString() {
		return "Location [id=" + id + ", locationName=" + locationName + ", latitude=" + latitude + ", longtitude="
				+ longtitude + "]";
	}

	
	
}
