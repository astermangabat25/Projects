package app.rest.controllers;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.components.SightingComponent;
import app.components.StrayAnimalComponent;
import app.entities.Location;
import app.entities.Sighting;
import app.repositories.LocationRepository;
import app.rest.dto.SightingRequest;

@Component
@Path("/sighting")
public class SightingController {

    @Autowired
    SightingComponent sightingcontroller;

    @Autowired
    StrayAnimalComponent animalcontroller;

    @Autowired
    private LocationRepository lRep;

    Logger logger = LoggerFactory.getLogger(SightingController.class);

    @POST
    @Path("/new")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Sighting add(SightingRequest sightingRequest) {
        String location = sightingRequest.getLocation();
        Double latitude = sightingRequest.getLatitude();
        Double longitude = sightingRequest.getLongtitude();
        String type = sightingRequest.getType();
        String color = sightingRequest.getColor();
        Boolean neutered = sightingRequest.getNeutered();
        String animalDescription = sightingRequest.getAnimalDescription();
        String comment = sightingRequest.getComment();

        Location l = lRep.findByName(location);
        if (l != null) {
            longitude = l.getLongitude();
            latitude = l.getLatitude();
        }
        else {
        	Location l1 = new Location();
        	l1.setName(location);
        	l1.setLatitude(latitude);
        	l1.setLongitude(longitude);
        	lRep.save(l1);
        }
        
        Long animalId = animalcontroller.add(type, color, neutered, animalDescription);
        return sightingcontroller.add(animalId, location, latitude, longitude, comment);
    }
}
