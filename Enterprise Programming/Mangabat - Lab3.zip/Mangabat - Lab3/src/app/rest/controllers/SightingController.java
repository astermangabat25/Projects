package app.rest.controllers;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.components.SightingComponent;
import app.components.StrayAnimalComponent;
import app.entities.Location;
import app.entities.Sighting;
import app.repositories.LocationRepository;

@Component
@Path("/sighting")
public class SightingController {
	@Autowired
	SightingComponent sightingcontroller;
	@Autowired
	StrayAnimalComponent animalcontroller;
	private LocationRepository lRep;
	
	Logger logger = LoggerFactory.getLogger(SightingController.class);
	
	@GET
	@Path("/new")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Sighting add(@FormParam("loc") String location,
			@FormParam("lat") Double latitude,
			@FormParam("longt") Double longtitude,
			@FormParam("t") String type,
			@FormParam("c") String color,
			@FormParam("n") Boolean neutered,
			@FormParam("ad") String animalDescription,
			@FormParam("com") String comment) {
		Long animalId = animalcontroller.add(type, color, neutered, animalDescription);
		Location l = lRep.findByName(location);
		if(l!=null) {
			longtitude = l.getLongtitude();
			latitude = l.getLatitude();
		}
		
		return sightingcontroller.add(animalId, location, latitude, longtitude, comment);
	}
}
