package app.rest.controllers;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import app.components.StrayAnimalComponent;
import app.entities.StrayAnimal;
import app.repositories.AnimalRepository;

@Component
@Path("/strayanimal")
public class StrayAnimalController {
	@Autowired
	StrayAnimalComponent controller;
	
	private AnimalRepository aRep;
	
	Logger logger = LoggerFactory.getLogger(StrayAnimalController.class);
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path("/add")
	public void add(@FormParam("t") String type,
			@FormParam("c") String color,
			@FormParam("n") boolean neutered,
			@FormParam("d") String description) {
		controller.add(type, color, neutered, description);
	}
	
	@GET
	@Path("/bytype")
	@Produces(MediaType.APPLICATION_JSON)
	public List<StrayAnimal> filterByType(@QueryParam("t") String type) {
		return controller.byType(type);
		
	}
	
	@GET
	@Path("/neutered")
	@Produces(MediaType.APPLICATION_JSON)
	public List<StrayAnimal> filterByNeutered(@QueryParam("n") Boolean neutered){
		return controller.byNeutered(neutered);
	}
	
}
